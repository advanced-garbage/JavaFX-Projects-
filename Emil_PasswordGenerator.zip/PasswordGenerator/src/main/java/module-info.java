module myid.passwordgenerator {
    requires javafx.controls;
    exports myid.passwordgenerator;
}
